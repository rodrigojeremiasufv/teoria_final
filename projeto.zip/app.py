from flask import Flask, render_template, request, url_for
from automato.arquivo import cria_automato_de_string, carrega_testes_de_uma_string
from automato.MaquinaTuring import MaquinaTuring
from automato.gera_imagem import gerar_grafo
from automato.AFNparaAFD import afn_para_afd
import logging

app = Flask(__name__)
logging.basicConfig(level=logging.DEBUG)

@app.route('/')
def index():
    try:
        automato_string = request.args.get('automato', '')
        fita = request.args.get('fita', '')
        afn = request.args.get('afn', '')

        results = []
        # Autômato e Alfabeto padrão que serão gerados assim que a página inicial é carregada
        automato_preset = '''s3,s0,s1,s2\nA,B\ns0,B,s1\ns3,A,s0\ns1,A,s2\ns2,B,s1\ns3\ns1'''
        alfabeto_preset = '''AB\nABAB\nABABAB\nA\nB\nABA\nBA\nBB\nABABB'''

        if afn:
            automato_convertido = afn_para_afd(afn)
            print(f'\n\n{automato_convertido} \n \n')
            return render_template('index.html', automato_preset=automato_convertido, alfabeto_preset="")

        elif automato_string and fita:
            img_path = "." + url_for('static', filename='img/img')
            automato = cria_automato_de_string(automato_string)
            gerar_grafo(automato, img_path)
            string_testes = carrega_testes_de_uma_string(fita)

            for test_string in string_testes:
                is_valid = automato.processa_string(test_string)
                status = 'ACEITA' if is_valid else 'REJEITADA'
                row_class = 'linha-passou' if is_valid else 'linha-rejeitada'
                results.append({'string': test_string, 'status': status, 'class': row_class})

        return render_template('index.html', results=results, automato_preset=automato_preset, alfabeto_preset=alfabeto_preset, retorno="")

    except Exception as e:
        print(f'Error: {e}')
        return render_template('index.html', automato_preset='', alfabeto_preset='', retorno=f"Erro: {str(e)}")


@app.route('/tutorial')
def tutorial():
    return render_template('tutorial.html')

@app.route('/converter')
def converter():
    afn_preset = """A,B\na,b,c\nA,b,B\nA,a,B\nA,b,B\nA,b,B\nA,e,C\nA\nB"""
    return render_template('converter.html', afn_preset = afn_preset)





@app.route('/turing')
def turing():
    maquina_turing = request.args.get('maquina_turing', '')
    fita = request.args.get('fita', '')
    
    logging.debug(f"maquina_turing: {maquina_turing}")
    logging.debug(f"fita: {fita}")
    
    if maquina_turing and fita:
        try:
        
            print(maquina_turing, fita)
            mt = MaquinaTuring(maquina_turing)
            saida, estado_final = mt.executar(fita)
            string_retorno = f"Saída: {saida}, Estado Final: {estado_final}."

            return render_template('turing.html', retorno=string_retorno)




        except Exception as e:
            logging.error(f"Erro: {e}")
            return render_template('turing.html', retorno="Erro ao processar o input da Fita.")
    else:
        return render_template('turing.html', retorno="Faltando transições ou símbolos da fita.")




if __name__ == '__main__':
    app.run(debug=True)
    