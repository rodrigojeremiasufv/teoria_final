from flask import Flask, render_template, request, url_for
from automato.arquivo import cria_automato_de_string, carrega_testes_de_uma_string
from automato.MaquinaTuring import MaquinaTuring, executar
from automato.gera_imagem import gerar_grafo
from automato.AFNparaAFD import afn_para_afd_minimizado
import logging

app = Flask(__name__)
logging.basicConfig(level=logging.DEBUG)

@app.route('/')
def index():
    try:
        automato_string = request.args.get('automato', '')
        fita = request.args.get('fita', '')
        afn = request.args.get('afn', '')

        results = []
        # Autômato e Alfabeto padrão que serão gerados assim que a página inicial é carregada
        automato_preset = '''s3,s0,s1,s2\nA,B\ns0,B,s1\ns3,A,s0\ns1,A,s2\ns2,B,s1\ns3\ns1'''
        alfabeto_preset = '''AB\nABAB\nABABAB\nA\nB\nABA\nBA\nBB\nABABB'''

        if afn:
            automato_convertido = afn_para_afd_minimizado(afn)
            print(f'\n\n{automato_convertido} \n \n')
            return render_template('index.html', automato_preset=automato_convertido, alfabeto_preset="")

        elif automato_string and fita:
            img_path = "." + url_for('static', filename='img/img')
            automato = cria_automato_de_string(automato_string)
            gerar_grafo(automato, img_path)
            string_testes = carrega_testes_de_uma_string(fita)

            for test_string in string_testes:
                is_valid = automato.processa_string(test_string)
                status = 'ACEITA' if is_valid else 'REJEITADA'
                row_class = 'linha-passou' if is_valid else 'linha-rejeitada'
                results.append({'string': test_string, 'status': status, 'class': row_class})

        return render_template('index.html', results=results, automato_preset=automato_preset, alfabeto_preset=alfabeto_preset, retorno="")

    except Exception as e:
        print(f'Error: {e}')
        return render_template('index.html', automato_preset='', alfabeto_preset='', retorno=f"Erro: {str(e)}")


@app.route('/tutorial')
def tutorial():
    return render_template('tutorial.html')

@app.route('/converter')
def converter():
    afn_preset = """A,B\na,b,c\nA,b,B\nA,a,B\nA,b,B\nA,b,B\nA,e,C\nA\nB"""
    return render_template('converter.html', afn_preset = afn_preset)



##MAQUINA DE TURING
@app.route('/problema1')
def problema1():
    maquina_turing_problema_1 ="""direita
final
direita,1,direita,1,dir
direita,0,direita,0,dir
direita, ,vaium, ,esq
vaium,1,vaium,0,esq
vaium,0,final,1,esq
vaium, ,final,1,esq
"""

    return render_template('turing.html', retorno='Incremento de um número Binário', retorno_2='Insira um número binário na fita e pressione "Processar a fita".',maquina_turing=maquina_turing_problema_1)


@app.route('/problema2')
def problema2():
    maquina_turing_problema_2 ="""q0
final
q0,1,q0,0,dir
q0, ,q0,0,esq
q0, ,final, ,H
"""


    return render_template('turing.html', retorno='Complemento um número binário.', retorno_2='Insira um número binário na fita e pressione "Processar a fita".',maquina_turing=maquina_turing_problema_2)



@app.route('/turing')
def turing():
    maquina_turing = request.args.get('maquina_turing', '')
    fita = request.args.get('fita', '')
    
    logging.debug(f"maquina_turing: {maquina_turing}")
    logging.debug(f"fita: {fita}")
    
    if maquina_turing and fita:
        try:
        
            estado_final_fita = executar(maquina_turing, fita)

            string_retorno = f"Estado Inicial da Fita: {fita}."
            string_retorno_2 = f"Estado Final da Fita:    {estado_final_fita}."


            return render_template('turing.html', retorno=string_retorno, retorno_2=string_retorno_2,maquina_turing="")




        except Exception as e:
            logging.error(f"Erro: {e}")
            return render_template('turing.html', retorno="Erro ao processar o input da Fita.",retorno_2="", maquina_turing="")
    else:
        return render_template('turing.html', retorno="Faltando transições ou símbolos da fita.", retorno_2="",maquina_turing="")




if __name__ == '__main__':
    app.run(debug=True)
    