class ClasseMaquinaTuring:
    def __init__(self, tape='', initial_state='q0', blank_symbol='_', transitions=None):
        self.tape = list(tape)
        self.head_position = 0
        self.current_state = initial_state
        self.blank_symbol = blank_symbol
        self.transitions = transitions if transitions else {}
        self.halted = False
    
    def step(self):
        if self.halted:
            raise Exception("Máquina de Turing já está em Halting.")
        
        current_symbol = self.tape[self.head_position] if self.head_position < len(self.tape) else self.blank_symbol
        transition_key = (self.current_state, current_symbol)
        
        if transition_key not in self.transitions:
            self.halted = True
            return
        
        next_state, symbol_to_write, direction = self.transitions[transition_key]
        
        if self.head_position < len(self.tape):
            self.tape[self.head_position] = symbol_to_write
        else:
            self.tape.append(symbol_to_write)
        
        self.current_state = next_state
        if direction == 'L':
            self.head_position -= 1
            if self.head_position < 0:
                self.tape.insert(0, self.blank_symbol)
                self.head_position = 0
        elif direction == 'R':
            self.head_position += 1
            if self.head_position >= len(self.tape):
                self.tape.append(self.blank_symbol)
    
    def run(self):
        while not self.halted:
            self.step()
    
    def get_tape_contents(self):
        return ''.join(self.tape).rstrip(self.blank_symbol)
    
    def get_current_state(self):
        return self.current_state
    
    def get_head_position(self):
        return self.head_position
    
def parse_transitions(transition_str):
    transitions = {}
    lines = transition_str.strip().split('\n')
    
    for line in lines:
        parts = line.split(',')
        
        if len(parts) != 5:
            raise ValueError("Cada linha de transição deve ter apenas 5 valores.")
        
        current_state, current_symbol, next_state, symbol_to_write, direction = parts
        
        if direction not in ['L', 'R']:
            raise ValueError("Direção tem que ser 'L' (esquerda) ou 'R' (direita).")
        
        transition_key = (current_state, current_symbol)
        transition_value = (next_state, symbol_to_write, direction)
        
        transitions[transition_key] = transition_value
    
    return transitions

