def convert_to_dfa(input_string):
    
    #Lê o input e faz o parsing 
    lines = input_string.strip().split('\n')
    
    states = lines[0].split(',')
    
    letters = lines[1].split(',')
    
    start = lines[-2]
    final_states = lines[-1].split(',')
    transitions = lines[2:-2]
    
    nfa_transitions = {}
    for transition in transitions:
        parts = transition.split(',')
        from_state, symbol, to_state = parts[0], parts[1], parts[2]
        if (from_state, symbol) not in nfa_transitions:
            nfa_transitions[(from_state, symbol)] = []
        nfa_transitions[(from_state, symbol)].append(to_state)
    

    #Instancia o Autômato
    dfa_states = []
    dfa_t_func = []
    dfa_final = []
    q = []
    visited_states = set()
    
    start_state = tuple([start])
    q.append(start_state)
    visited_states.add(start_state)
    
    dfa_transitions = {}
    
    while q:
        in_state = q.pop(0)
        for symbol in letters:
            dest = []
            
            for n_state in in_state:
                if (n_state, symbol) in nfa_transitions:
                    dest.extend(nfa_transitions[(n_state, symbol)])
            
            if dest:
                f_dest = tuple(sorted(set(dest))) 
                dfa_transitions[(in_state, symbol)] = f_dest
                
                if f_dest not in visited_states:
                    q.append(f_dest)
                    visited_states.add(f_dest)
    
    for key, value in dfa_transitions.items():
        temp_list = [[key[0], key[1], value]]
        dfa_t_func.extend(temp_list)
    
    for q_state in visited_states:
        if any(state in final_states for state in q_state):
            dfa_final.append(q_state)
    
    dfa_string = []

    state_labels = [f's{i}' for i in range(len(visited_states))]
    dfa_string.append(','.join(state_labels))
    
    dfa_string.append(','.join(letters))
    
    for (from_state, symbol), to_states in dfa_transitions.items():
        for to_state in to_states:
            dfa_string.append(f"{','.join(from_state)},{symbol},{','.join(to_state)}")
    
    dfa_string.append(','.join(start_state))
    
    dfa_string.append(','.join(','.join(state) for state in dfa_final))
    
    return '\n'.join(dfa_string)
