from flask import Flask, render_template, request, url_for
from automato.arquivo import cria_automato_de_string, carrega_testes_de_uma_string
from automato.MaquinaTuring import ClasseMaquinaTuring, parse_transitions
from automato.gera_imagem import gerar_grafo
from automato.AFNparaAFD import convert_to_dfa
import logging

app = Flask(__name__)
logging.basicConfig(level=logging.DEBUG)

@app.route('/')
def index():
    automato_string = request.args.get('automato', '')
    alfabeto = request.args.get('alfabeto', '')
    
    afn  = request.args.get('afn', '')

    results = []
    #Autômato e Alfabeto padrão que serão gerados assim que a página inicial é carregada
    automato_preset = '''s3,s0,s1,s2\nA,B\ns0,B,s1\ns3,A,s0\ns1,A,s2\ns2,B,s1\ns3\ns1'''
    alfabeto_preset = '''AB\nABAB\nABABAB\nA\nB\nABA\nBA\nBB\nABABB'''

    if afn:
        automato_convertido = convert_to_dfa(afn)
        print(f'\n\n{automato_convertido} \n \n')
        return render_template('index.html', automato_preset=automato_convertido, alfabeto_preset="opaopa")

    elif automato_string and alfabeto:
        img_path = "." + url_for('static', filename='img/img')
        automato = cria_automato_de_string(automato_string)
        gerar_grafo(automato, img_path)
        string_testes = carrega_testes_de_uma_string(alfabeto)
        
        for test_string in string_testes:
            is_valid = automato.processa_string(test_string)
            status = 'ACEITA' if is_valid else 'REJEITADA'
            row_class = 'linha-passou' if is_valid else 'linha-rejeitada'
            results.append({'string': test_string, 'status': status, 'class': row_class})
    
    return render_template('index.html', results=results, automato_preset=automato_preset, alfabeto_preset=alfabeto_preset)

@app.route('/tutorial')
def tutorial():
    return render_template('tutorial.html')

@app.route('/converter')
def converter():
    return render_template('converter.html')





@app.route('/turing')
def turing():
    maquina_turing = request.args.get('maquina_turing', '')
    alfabeto = request.args.get('alfabeto', '')
    
    logging.debug(f"maquina_turing: {maquina_turing}")
    logging.debug(f"alfabeto: {alfabeto}")
    
    if maquina_turing and alfabeto:
        try:
            transitions = parse_transitions(maquina_turing)
            logging.debug(f"Transições: {transitions}")
            tm = ClasseMaquinaTuring(tape=alfabeto, initial_state='q0', transitions=transitions)
            tm.run()
            
            final_tape = tm.get_tape_contents()
            final_state = tm.get_current_state()
            head_position = tm.get_head_position()
            
            return render_template('turing.html', 
                                   retorno="Máquina de Turing executou com sucesso",
                                   final_tape=final_tape,
                                   final_state=final_state,
                                   head_position=head_position)
        except Exception as e:
            logging.error(f"Erro: {e}")
            return render_template('turing.html', retorno="Erro ao processar o input da Fita.")
    else:
        return render_template('turing.html', retorno="Faltando transições ou símbolos do alfabeto.")




if __name__ == '__main__':
    app.run(debug=True)
    