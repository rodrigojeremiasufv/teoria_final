if __name__ == "__main__":
    print("Função main ainda não faz nada.\n")