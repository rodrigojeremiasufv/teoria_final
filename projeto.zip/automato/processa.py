#Este arquivo define a função principal


import sys
from arquivo import *
from Automato import *

def processa():
    if len(sys.argv) != 3:
        print("Uso correto: python3 main.py <arquivo_automato.txt> <arquivo_strings.txt>")
        sys.exit(1)

    nome_arquivo_automato = sys.argv[1]
    nome_arquivo_strings = sys.argv[2]

    try:
        automato = cria_automato_de_arquivo(nome_arquivo_automato)
        print("--------------- AUTOMATO CRIADO ----------------")
        print(automato)
        print("\n")
        print("----------------- RESULTADO --------------------")
        resultados = processa_strings_arquivo(automato, nome_arquivo_strings)
        for string, resultado in resultados.items():
            temp = ""
            if resultado:
                temp = "[ APROVADO  ]"
            else:
                temp = "[ REJEITADO ]"
            print(temp, string)

    except Exception as e:
        print(f"Erro ao processar os arquivos: {e}")
        sys.exit(1)


def processa_string():
    string_automato = """s3,s0,s1,s2
A,B
s3,A,s0
s0,B,s1
s1,A,s2
s2,B,s1
s3
s1
"""
    automato = cria_automato_de_string(string_automato)
    print("--------------- AUTOMATO CRIADO ----------------")
    print(automato)
    print("\n")
        
processa_string()

