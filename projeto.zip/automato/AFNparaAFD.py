def afn_para_afd(input_string):
    input_string = input_string.replace('\r', '')
    linhas = input_string.strip().split('\n')
    
    estados = linhas[0].split(',')
    simbolos = linhas[1].split(',')

    estado_inicial = linhas[-2]
    estados_finais = linhas[-1].split(',')
    transicoes = linhas[2:-2]

    transicoes_afn = {}
    for transicao in transicoes:
        transicao_unica = transicao.split(',')

        transicao_de, valor, transicao_para = transicao_unica[0], transicao_unica[1], transicao_unica[2]
        if (transicao_de, valor) not in transicoes_afn:
            transicoes_afn[(transicao_de, valor)] = []
        transicoes_afn[(transicao_de, valor)].append(transicao_para)

    transicoes_afd = {}
    visitado = set()
    estado_inicial = tuple([estado_inicial])
    q = [estado_inicial]
    visitado.add(estado_inicial)
    
    while q:
        estado_atual = q.pop(0)
        for valor in simbolos:
            dest = []
            for estado_n in estado_atual:
                if (estado_n, valor) in transicoes_afn:
                    dest.extend(transicoes_afn[(estado_n, valor)])
            if dest:
                f_dest = tuple(sorted(set(dest)))
                if (estado_atual, valor) not in transicoes_afd:
                    transicoes_afd[(estado_atual, valor)] = f_dest
                if f_dest not in visitado:
                    q.append(f_dest)
                    visitado.add(f_dest)

    afd_string = []
    
    def formata(estado):
        return ','.join(estado) if isinstance(estado, tuple) else estado
    afd_string.append(','.join(estados))

    afd_string.append(','.join(simbolos))

    for (transicao_de, valor), to_states in transicoes_afd.items():
        formatted_from_state = formata(transicao_de)
        for transicao_para in to_states:
            formatted_to_state = formata(transicao_para)
            afd_string.append(f"{formatted_from_state},{valor},{formatted_to_state}")
    

    afd_string.append(formata(estado_inicial))
    

    afd_string.append(','.join(estados_finais))
    print("OUTPUT: \n")
    print(afd_string)
    return '\n'.join(afd_string).strip()


#teste
if __name__ == '__main__':
    string_input = """A,B
a,b,c
A,b,B
A,a,B
A,b,B
A,b,B
A,e,C
A
B
"""
    automato = afn_para_afd(string_input)
    print(automato)
