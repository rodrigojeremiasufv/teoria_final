def afn_para_afd(input_string):
    #parsing, necessário para receber oa definição do autômato via string
    input_string = input_string.replace('\r', '')
    linhas = input_string.strip().split('\n')
    
    estados = linhas[0].split(',')
    simbolos = linhas[1].split(',')

    estado_inicial = linhas[-2]
    estados_finais = linhas[-1].split(',')
    transicoes = linhas[2:-2]



    #cria um dicionário, onde a chave é um conjunto de estados e símbolos e o valor é o conjunto de estados possívei
    transicoes_afn = {}
    for transicao in transicoes:
        transicao_unica = transicao.split(',')

        transicao_de, valor, transicao_para = transicao_unica[0], transicao_unica[1], transicao_unica[2]
        if (transicao_de, valor) not in transicoes_afn:
            transicoes_afn[(transicao_de, valor)] = []
        transicoes_afn[(transicao_de, valor)].append(transicao_para)
    
    #Inicializa um AFD em branco
    transicoes_afd = {}
    visitado = set()
    estado_inicial = tuple([estado_inicial])
    q = [estado_inicial]
    visitado.add(estado_inicial)
    
    # Processamento
    # Determina os estados possíveis a partir de cada um dos estados, em seguida, cria um novo conjunto de estados
    # e os inserem na tabela de estados do AFD.
    # Adiciona recursivamente novos estados à fila caso eles ainda não forem processados
    
    while q:
        estado_atual = q.pop(0)
        for valor in simbolos:
            dest = []
            for estado_n in estado_atual:
                if (estado_n, valor) in transicoes_afn:
                    dest.extend(transicoes_afn[(estado_n, valor)])
            if dest:
                f_dest = tuple(sorted(set(dest)))
                if (estado_atual, valor) not in transicoes_afd:
                    transicoes_afd[(estado_atual, valor)] = f_dest
                if f_dest not in visitado:
                    q.append(f_dest)
                    visitado.add(f_dest)

    #formata a string de acordo com o retorno esperado.
    afd_string = []
    def formata(estado):
        return ','.join(estado) if isinstance(estado, tuple) else estado
    afd_string.append(','.join(estados))
    afd_string.append(','.join(simbolos))
    for (transicao_de, valor), to_states in transicoes_afd.items():
        formatted_from_state = formata(transicao_de)
        for transicao_para in to_states:
            formatted_to_state = formata(transicao_para)
            afd_string.append(f"{formatted_from_state},{valor},{formatted_to_state}")
    afd_string.append(formata(estado_inicial))
    afd_string.append(','.join(estados_finais))
    print("OUTPUT: \n")
    print(afd_string)
    return '\n'.join(afd_string).strip()





##função para fazer o parsingo do AFD, fiz uma função diferente, pois AFD não tem que lidar com estados vazios.
def parse_afd(afd_string):
    linhas = afd_string.strip().split('\n')
    
    estados = linhas[0].split(',')
    simbolos = linhas[1].split(',')
    
    transicoes = {}
    for transicao in linhas[2:-2]:
        transicao_de, valor, transicao_para = transicao.split(',')
        if transicao_de not in transicoes:
            transicoes[transicao_de] = {}
        transicoes[transicao_de][valor] = transicao_para

    estado_inicial = linhas[-2]
    estados_finais = set(linhas[-1].split(','))
    
    return estados, simbolos, transicoes, estado_inicial, estados_finais

def minimizar_afd(afd_string):
    estados, simbolos, transicoes, estado_inicial, estados_finais = parse_afd(afd_string)
    

    #Divide todos os estados em estados finais e não finais
    finais = set(estados_finais)
    nao_finais = set(estados) - finais
    particao = [finais, nao_finais]


    #Depois de raliziar a separação, a função eliminacao faz a eliminação dos dados redundantes da tabela
    #de modo a deixar apenas estados com comportamento único
    def eliminacao(particao):
        nova_particao = []
        grupo_map = {}
        
        for grupo in particao:
            grupos_de_transicoes = {}
            
            for estado in grupo:
                chave = tuple(
                    transicoes.get(estado, {}).get(simbolo, None) for simbolo in simbolos
                )
                if chave not in grupos_de_transicoes:
                    grupos_de_transicoes[chave] = set()
                grupos_de_transicoes[chave].add(estado)
                
            nova_particao.extend(grupos_de_transicoes.values())
            
        return nova_particao

    while True:
        nova_particao = eliminacao(particao)
        if nova_particao == particao:
            break
        particao = nova_particao
    
    #Depois de eliminação dos estados redundades, o algorítmo constrói uma nova AFD com os estados restantes
    estado_para_grupo = {}
    for i, grupo in enumerate(particao):
        novo_estado = f"q{i}"
        for estado in grupo:
            estado_para_grupo[estado] = novo_estado

    novo_transicoes = {}
    novo_finais = set()
    
    for grupo in particao:
        exemplo_estado = next(iter(grupo))
        novo_estado = estado_para_grupo[exemplo_estado]
        novo_transicoes[novo_estado] = {}
        for simbolo in simbolos:
            destino = transicoes.get(exemplo_estado, {}).get(simbolo, None)
            if destino is not None:
                destino_novo = estado_para_grupo[destino]
                novo_transicoes[novo_estado][simbolo] = destino_novo
        if exemplo_estado in finais:
            novo_finais.add(novo_estado)
    
    novo_estado_inicial = estado_para_grupo[estado_inicial]
    
    #Formatação da saída
    afd_minimizado_string = []
    def formata(estado):
        return estado
    
    # Obter todos os estados únicos no AFD minimizado
    estados_minimizados = set()
    for grupo in particao:
        estado_minimizado = estado_para_grupo[next(iter(grupo))]
        estados_minimizados.add(estado_minimizado)
    
    afd_minimizado_string.append(','.join(sorted(estados_minimizados)))
    afd_minimizado_string.append(','.join(simbolos))
    
    for transicao_de, trans in novo_transicoes.items():
        for valor, transicao_para in trans.items():
            afd_minimizado_string.append(f"{transicao_de},{valor},{transicao_para}")
    
    afd_minimizado_string.append(novo_estado_inicial)
    afd_minimizado_string.append(','.join(sorted(novo_finais)))
    
    #retorna o afd minizado
    return '\n'.join(afd_minimizado_string).strip()


def afn_para_afd_minimizado(string_input):
    automato = afn_para_afd(string_input)
    afd_minimizado = minimizar_afd(automato)
    return afd_minimizado

# Teste
if __name__ == '__main__':
    string_input = """A,B
a,b,c
A,b,B
A,a,B
A,b,B
A,b,B
A,e,C
A
B
"""
    automato = afn_para_afd(string_input)
    print("AFD:")
    print(automato)
    
    afd_minimizado = minimizar_afd(automato)
    print("\nAFD Minimizado:")
    print(afd_minimizado)
