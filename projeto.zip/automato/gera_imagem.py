from graphviz import  Digraph # type: ignore
import os
os.environ['PATH'] += ':/usr/bin/' 



def gerar_grafo(automato, arquivo_saida='img'):
    """
    Gera uma representação gráfica do autômato finito usando Graphviz.

    Args:
    - automato: Instância da classe AutomatoFinito.
    - arquivo_saida: Nome do arquivo de saída para o gráfico gerado.
    """
    # # preto no branco
    # dot = Digraph(comment='Autômato Fini to', node_attr={'shape': 'circle'}, 
    #               graph_attr={'size': '12,8!', 'ratio': 'auto', 'rankdir': 'LR' })

    #branco no preto
    dot = Digraph(comment='Autômato Finito', node_attr={'shape': 'circle', 'fontcolor': '#f0f0f0', 'color': '#f0f0f0'}, 
                  graph_attr={'size': '12,8!', 'ratio': 'auto', 'rankdir': 'LR',
                              'bgcolor': '#1e1e1e'},  # Define a cor de fundo
                  edge_attr={'color': '#f0f0f0', 'fontcolor': '#f0f0f0'})  # Define a cor do texto dos nós

    # Adiciona o estado inicial
    dot.node('start', 'Inicio', shape='point', width='0')
    dot.edge('start', automato.estado_inicial, label='')

    # Adiciona todos os estados e transições
    for estado in automato.estados:
        if estado in automato.estados_finais:
            dot.node(estado, shape='doublecircle', label=estado)
        else:
            dot.node(estado, shape='circle', label=estado)

    # Adiciona as transições
    for estado_origem, transicoes_saida in automato.transicoes.items():
        for letra, estado_destino in transicoes_saida.items():
            dot.edge(estado_origem, estado_destino, label=letra)

    # Renderiza e salva o gráfico em um arquivo
    dot.render(arquivo_saida, format='png', cleanup=True)
    print(f'Gráfico gerado e salvo como {arquivo_saida}.png.')



