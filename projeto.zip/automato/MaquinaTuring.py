class Fita(object):
    # Definição de Fita
    vazio = " "
    def __init__(self, string_entrada_fita = ""):
        self.__fita = dict((enumerate(string_entrada_fita)))

        
    def __str__(self):
        string_fita = ""
        menor_indice = min(self.__fita.keys()) 
        maior_indice = max(self.__fita.keys())
        for i in range(menor_indice, maior_indice):
            string_fita += self.__fita[i]
        return string_fita    
   
    def __getitem__(self,indice):
        if indice in self.__fita:
            return self.__fita[indice]
        else:
            return Fita.vazio

    def __setitem__(self, pos, char):
        self.__fita[pos] = char 

        
class MaquinaTuring(object):
    #Inicializa a máquina vazia
    def __init__(self,  fita = "",  vazio = " ", estado_inicial = "", estados_finais = None, transicoes = None):
        self.__fita = Fita(fita)
        self.__posicao = 0
        self.__vazio = vazio
        self.__estado_atual = estado_inicial
        if transicoes == None:
            self.__transicoes = {}
        else:
            self.__transicoes = transicoes
        if estados_finais == None:
            self.__estados_finals = set()
        else:
            self.__estados_finals = set(estados_finais)
            
    #Retorna o estado atual da fita
    def fita(self): 
        return str(self.__fita)
    
    
    #realiza um passo do processamento da máquina
    def passo(self):
        valor_fita = self.__fita[self.__posicao]
        x = (self.__estado_atual, valor_fita)
        if x in self.__transicoes:
            y = self.__transicoes[x]
            self.__fita[self.__posicao] = y[1]
            if y[2] == "dir":
                self.__posicao += 1
            elif y[2] == "esq":
                self.__posicao -= 1
            self.__estado_atual = y[0]

    #verifica o estado final
    def verifica_final(self):
        if self.__estado_atual in self.__estados_finals:
            return True
        else:
            return False
    
#Como estou utilizando o método GET para definir uma nova máquina de Turing, há a necessidade de de parsear a string de input
def parse(config_string, fita = ''):
    
    #separa linhas
    linhas = config_string.replace('\r', '\r')
    linhas = config_string.strip().split('\n')


    #linhas
    estado_inicial = linhas[0].strip()
    estados_finais = set(map(str.strip, linhas[1].split(',')))

    transicoes = {}
    for linha in linhas[2:]:
        linha = linha.strip().split(',')
        # print(linha, len(linha))

        if len(linha) == 5:
            nova_transicao = {(linha[0],linha[1]):(linha[2],linha[3],linha[4])}
            # print(linha[0], linha[1])
            # print(linha[2], linha[3], linha[4])
            transicoes.update(nova_transicao)
        else:
            raise Exception("Definição de transições inválida.")     
    # print(transicoes)
    # print(transicoes_original)
    # Instantiate the Turing machine
    maquina_parseada = MaquinaTuring(
        fita=fita,
        estado_inicial=estado_inicial,
        estados_finais=estados_finais,
        transicoes=transicoes
    )
    return maquina_parseada


def executar(mt, fita):
    maquina = parse(mt, fita)
    while not maquina.verifica_final():
        maquina.passo()

    return maquina.fita()    



if __name__ == '__main__':



#     string_teste = """init
# final
# init,0,init,1,dir
# init,1,init,0,dir
# init, ,final, ,H"""

#     final = executar(string_teste, "01010")
#     print(final)

    string_teste2 ="""direita
final
direita,1,direita,1,dir
direita,0,direita,0,dir
direita, ,vaium, ,esq
vaium,1,vaium,0,esq
vaium,0,final,1,esq
vaium, ,final,1,esq
"""

    final = executar(string_teste2, "01010")
    print(final)


