class MaquinaTuring:
    def __init__(self, string_input):
        self.estado_atual = None
        self.estado_aceitacao = None
        self.estado_rejeicao = None
        self.fita = []
        self.posicao_cabeca = 0
        self.transicoes = {}
        


        self._parse_descricao(string_input)
        
    def _parse_descricao(self, string_input):
        linhas = string_input.strip().split('\n')
        
        alfabeto_info, estados_info = linhas[0].split(','), linhas[1].split(',')
        alfabeto_fita = alfabeto_info[0].split()
        alfabeto_cabeca = alfabeto_info[1].split()
        
        self.estado_atual = estados_info[0]
        self.estado_aceitacao = estados_info[1]
        self.estado_rejeicao = estados_info[2]
        
        self.transicoes = {}
        for regra in linhas[2:]:
            estado_atual, simbolo_atual, simbolo_escrito, direcao, novo_estado = regra.split(',')
            if estado_atual not in self.transicoes:
                self.transicoes[estado_atual] = {}
            self.transicoes[estado_atual][simbolo_atual] = (simbolo_escrito, direcao, novo_estado)
        
    def executar(self, entrada):
        self.fita = list(entrada)
        self.posicao_cabeca = 0
        self.estado_atual = self.estado_aceitacao
        
        while self.estado_atual != self.estado_aceitacao and self.estado_atual != self.estado_rejeicao:
            simbolo_atual = self.fita[self.posicao_cabeca] if self.posicao_cabeca < len(self.fita) else ' '
            if simbolo_atual not in self.transicoes.get(self.estado_atual, {}):
                self.estado_atual = self.estado_rejeicao
                break
            
            simbolo_escrito, direcao, novo_estado = self.transicoes[self.estado_atual][simbolo_atual]
            self.fita[self.posicao_cabeca] = simbolo_escrito
            self.estado_atual = novo_estado
            
            if direcao == 'D':
                self.posicao_cabeca += 1
                if self.posicao_cabeca >= len(self.fita):
                    self.fita.append(' ')
            elif direcao == 'E':
                self.posicao_cabeca -= 1
                if self.posicao_cabeca < 0:
                    self.fita.insert(0, ' ')
                    self.posicao_cabeca = 0
        
        return ''.join(self.fita), self.estado_atual

#teste
if __name__ == '__main__':
    descricao_maquina = """
0 1,0 1
q0,q_aceitacao,q_rejeicao
q0,0,1,D,q1
q1,1,0,D,q_aceitacao
"""

    maquina = MaquinaTuring(descricao_maquina)
    saida, estado_final = maquina.executar("0000")

    print(f"Saída: {saida}")
    print(f"Estado Final: {estado_final}")
